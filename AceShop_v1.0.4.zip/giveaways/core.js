const { GiveawaysManager } = require('discord-giveaways')

async function manager(client) {
  const create = new GiveawaysManager(client, {
    storage: "./giveaways/storage.json",
    updateCountdownEvery: 20000,
    hasGuildMembersIntent: true,
    default: {
      botsCanWin: false,
      exemptPermissions: [],
      embedColor: 'YELLOW',
      embedColorEnd: 'GREEN',
      reaction: '🎉'
    }
  })

  return client.giveaway = create;
}

module.exports = manager