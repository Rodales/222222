const color = require('colors')

module.exports = async (client, commands) => {
  console.log(color.magenta('[Discord]') + color.yellow(` Carregando o total de ${color.red(commands.length)} comandos.`));
  commands.forEach(c => {
    try {
      const props = require(`../../commands/${c}`);
      if (c.split(".").slice(-1)[0] !== "js") return;

      console.log(color.magenta('[Discord]') + color.green(` o Comando ${color.white(props.help.name)} foi carregado com sucesso!`));

      if (props.init) props.init(client);

      client.commands.set(props.help.name, props);
      if (props.help.aliases) {
        props.alias = true;
        props.help.aliases.forEach(alias => client.commands.set(alias, props));
      }
    } catch (e) {
      console.log(color.magenta('[Discord]') + color.red(` Erro ao carregar comando ${color.gray(c)}:`) + e);
    }
  });
}