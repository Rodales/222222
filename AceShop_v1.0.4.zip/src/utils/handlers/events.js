const c = require('colors')
module.exports = async (client, evtFiles) => {
  console.log(c.magenta('[Discord]') + c.yellow(`Carregando o total de ${c.red(evtFiles.length)} eventos.`));

  evtFiles.forEach(f => {
    const eventName = f.split(".")[0];
    const event = require(`../../events/${f}`);

    client.on(eventName, event.bind(null, client));

    console.log(c.magenta('[Discord]') + c.green(` o Módulo ${c.gray(eventName)} foi ativo com sucesso!`));

  });
}