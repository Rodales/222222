async function createMuteRole(message) {
  const role = await message.guild.roles.create({
    data: {
      name: "muted",
      color: "#36393f"
    },
    reason: "Cargo de mutes inexistente."
  })

  return role
}

async function updateChannelsPermissions(channelEvent) {
  const guild = await channelEvent.guild
  const role = await guild.roles.cache.find(f => f.name === "muted")

  return await guild.channels.cache.map(async channel => {
    await channel.updateOverwrite(role.id, { SEND_MESSAGES: false })
  })
}

module.exports = { createMuteRole, updateChannelsPermissions }