const { MessageEmbed } = require('discord.js')
const config = require('../../../baseConfigs.json');
async function createTicket(client, reaction, user) {

  const g = client.guilds.cache.get(config.guild.id);
  let hasChannel = false

  reaction.users.remove(user.id)

  switch (reaction.emoji.id) {
    case emojis.id.money: {
      await g.channels.cache.map(channel => {
        if (channel.parentID === "854911602451939358" && channel.topic === user.id)
          return hasChannel = true
      })
      if (hasChannel)
        return g.members.cache.get(user.id).send(`${emojis.error} | Você não pode abrir outro ticket até que o seu atual seja fechado!`).catch(console.log)
      return core(`shop-${user.tag}`, "854911602451939358");
    }
    case emojis.id.info: {
      await g.channels.cache.map(channel => {
        if (channel.parentID === "854921392498671657" && channel.topic === user.id)
          return hasChannel = true
      })
      if (hasChannel)
        return g.members.cache.get(user.id).send(`${emojis.error} | Você não pode abrir outro ticket até que o seu atual seja fechado!`)
      return core(`question-${user.tag}`, "854921392498671657");
    }
  }

  async function callMessages(channel) {
    const embed = new MessageEmbed().setDescription(`:flag_br: - \`Português\`\n> ${emojis.info} Aguarde, em breve você será atendido por nossa equipe, enquanto isso, você pode indo nos contando o motivo de ter aberto este ticket.\n:flag_us: - \`English\`\n> ${emojis.info} Wait, you will soon be attended by our team, in the meantime you can talk about the reason for this ticket.`)

    channel.send(`${emojis.ok} <@&846466306521301034> & <@!${channel.topic}>`, embed)
  }

  async function core(name, parent) {
    reaction.message.guild.channels.create(name, {
      parent: parent,
      type: 'text',
      topic: user.id
    }).then(async channel => {
      await channel.updateOverwrite(user.id, { VIEW_CHANNEL: true })

      return callMessages(channel);
    })
  }
}

module.exports = createTicket