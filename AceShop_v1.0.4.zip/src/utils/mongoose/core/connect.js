const MongoDB = require('mongoose');
const c = require('colors');

module.exports = MongoDB.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useCreateIndex: true,
  useUnifiedTopology: true,
  useFindAndModify: false
});

console.log(c.white('[MongoDB]') + c.green(' Successfully logged!'))