const { Schema, model } = require('mongoose');

const schematic = new Schema({
  member: String,
  staff: String,
  memberData: String,
  staffData: String,
  account: String,
  date: String,
  details: String,
  img: Array
})

module.exports = model('pagamentos', schematic)