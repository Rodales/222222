const { Schema, model } = require('mongoose');

const accounts = new Schema({
  email: {
    type: String,
    unique: true,
    required: true
  },
  password: {
    type: String,
    required: true
  },
  imgur: {
    type: String,
    required: true
  },
  details: {
    type: String,
    required: true
  },
  isAnnounced: String,
  blizzard: String,
  banned: String,
  banDate: String,
  blizzardEmail: String,
  blizzardPass: String
})

module.exports = model('accounts', accounts)