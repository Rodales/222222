const c = require('colors')
const configs = require('../../baseConfigs.json');

module.exports = async (client) => {

  console.log(c.blue("[Discord]") + c.green(' Successfully logged!'));
  console.log(c.green(`[${c.gray(client.user.username)}] - [${c.red(client.users.cache.size)} Members]`))
  console.log(c.yellow('Bot by Vitu™#2002(293913134748401674)'))
  console.log(c.white('For issues contact') + c.red(' dev@karmabot.xyz'))

  const g = client.guilds.cache.get(configs.guild.id)
  const cc = g.channels.cache.get(configs.captcha.channelID)
  const ct = g.channels.cache.get(configs.tickets.channelID)
  cc.messages.fetch(configs.captcha.messageID);
  ct.messages.fetch(configs.tickets.messageID)

  client.user.setStatus("online");

  // PLAYING
  // LISTENING
  // WATCHING

  client.user.setActivity({
    name: "AceShop",
    type: "PLAYING"
  });

}