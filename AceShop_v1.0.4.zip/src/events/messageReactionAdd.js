const Client = require('../../baseConfigs.json')
module.exports = async (client, reaction, user) => {

  const r = reaction.emoji.id;


  if (reaction.message.id == Client.captcha.messageID) {
    if (r == Client.captcha.emoji) {
      reaction.message.guild.channels.cache.get(Client.logs.registredMember).send(`${emojis.ok} ${user} Passou pelo captcha. \`${user.tag} [${user.id}]\``)
      const member = reaction.message.guild.members.cache.get(user.id)
      return Client.captcha.rolesID.map(r => member.roles.add(r));
    } else {
      return;
    }
  } else if (reaction.message.id == Client.tickets.messageID) {
    if (r == Client.tickets.emojis.shop) {
      return require('../utils/functions/createTicket')(client, reaction, user);
    } else if (r == Client.tickets.emojis.asks) {
      return require('../utils/functions/createTicket')(client, reaction, user);
    } else {
      return;
    }
  } else {
    return;
  }
}