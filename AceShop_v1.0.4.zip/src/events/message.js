module.exports = async (client, message) => {

  antiSpam.message(message)

  if (message.author.bot) return

  if (message.content.indexOf(process.env.PREFIX) !== 0) return

  const args = message.content
    .slice(process.env.PREFIX.length)
    .trim()
    .split(/ +/g);
  const command = args.shift().toLowerCase();

  const cmd = client.commands.get(command);
  if (!cmd) return;

  console.log(`[Discord] ${message.author.tag} (${message.author.id}) executou o comando ${cmd.help.name} no canal ${message.channel.name}.`)

  cmd.run(client, message, args);
};
