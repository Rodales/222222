const { MessageAttachment, MessageEmbed } = require("discord.js")

exports.run = async (client, message, args) => {
  if (!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send(`${emojis.error} | ${message.author} Ops! Este comando é de uso exclusivo da staff!`)

  const filter = (u) => { return u.author.id === message.author.id }
  message.channel.send(`${emojis.load} | ${message.author} Você deseja uma mensagem ou embed?`).then(async msg => {
    msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async type => {
      const a = type.first().content
      if (['embed', 'em', 'en', 'enbed'].includes(a.toLowerCase())) {
        msg.channel.send(`${emojis.load} | ${message.author} Qual o título da embed? ("x" para sem título)`).then(async msg1 => {
          msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async resp1 => {
            msg.channel.send(`${emojis.load} | ${message.author} Qual a mensagem da embed?`).then(async msg2 => {
              msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async resp2 => {
                msg.channel.send(`${emojis.load} | ${message.author} Qual a imagem da embed? ("x" para sem imagem)`).then(async msg3 => {
                  msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async resp3 => {
                    msg.channel.send(`${emojis.load} | ${message.author} Qual a thumbnail da embed? ("x" para sem thumbnail)`).then(async msg3 => {
                      msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async resp4 => {
                        msg.channel.send(`${emojis.load} | ${message.author} Qual a cor (hex ou nome, ex: \`#FFFF00\` ou \`YELLOW\`) da embed? ("x" para sem cor)`).then(async msg3 => {
                          msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async resp5 => {
                            msg.channel.send(`${emojis.load} | ${message.author} Qual o canal para enviar a embed?`).then(async msg4 => {
                              msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async resp6 => {
                                const data = {
                                  title: String(resp1.first().content),
                                  description: String(resp2.first().content),
                                  image: String(resp3.first().content),
                                  thumb: String(resp4.first().content),
                                  color: String(resp5.first().content),
                                  id: String(resp6.first().mentions.channels.first().id)
                                }

                                const embed = new MessageEmbed().setDescription(data.description)

                                if (data.title !== "x") embed.setTitle(data.title)
                                if (data.image !== "x") embed.setImage(data.image)
                                if (data.thumb !== "x") embed.setThumbnail(data.thumb)
                                if (data.color !== "x") embed.setColor(data.color)

                                const channel = await msg.guild.channels.cache.get(data.id)

                                if (!channel) return message.channel.send(`${emojis.error} | ${message.author} Ops! O ID inserido é inválido!`)

                                channel.send(embed)
                              }).catch(err => {
                                console.log(err)
                                return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder o id do canal para enviar a embed!`)
                              })
                            })
                          }).catch(err => {
                            console.log(err)
                            return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder a cor embed!`)
                          })
                        })
                      }).catch(err => {
                        console.log(err)
                        return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder a thumbnail embed!`)
                      })
                    })
                  }).catch(err => {
                    return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder a imagem da embed!`)
                  })
                })
              }).catch(err => {
                return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder a mensagem da embed!`)
              })
            })
          }).catch(err => {
            return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder qual o título da embed!`)
          })
        })
      } else if (['msg', 'mensagem', 'normal', 'message'].includes(a.toLowerCase())) {
        msg.channel.send(`${emojis.load} | ${message.author} Qual a mensagem?`).then(async msg1 => {
          msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async resp1 => {
            msg.channel.send(`${emojis.load} | ${message.author} Você deseja enviar alguma imagem junto? \`LINK\`("x" para sem imagem)`).then(async msg2 => {
              msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async resp2 => {
                msg.channel.send(`${emojis.load} | ${message.author} Qual o canal que você deseja enviar a mensagem?`).then(async msg3 => {
                  msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async resp3 => {
                    const data = {
                      msg: resp1.first().content,
                      img: resp2.first().content,
                      id: resp3.first().mentions.channels.first() || message.channel
                    }

                    const channel = await msg.guild.channels.cache.get(data.id.id)

                    if (!channel) return message.channel.send(`${emojis.error} | ${message.author} Ops! O ID inserido é inválido!`)

                    if (data.img == "x") {
                      channel.send(data.msg)
                    } else {
                      channel.send(data.msg,
                        { files: [data.img] })
                    }
                  }).catch(err => {
                    console.log(err)
                    return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder o canal!`)
                  })
                })
              }).catch(err => {
                return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder a imagem!`)
              })
            })
          }).catch(err => {
            return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder a mensagem!`)
          })
        })
      } else {
        return message.channel.send(`${emojis.error} | ${message.author} Ops! Eu acho que eu disse \`mensagem\` ou \`embed\`!`)
      }
    }).catch(err => {
      return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder se deseja uma \`mensagem\` ou \`embed\`!`)
    })
  })
}

exports.help = {
  name: "say",
  aliases: ['dizer', 'embed']
}