const { MessageEmbed } = require("discord.js");
const Client = require('../../baseConfigs.json')
const { createMuteRole, updateChannelsPermissions } = require('../utils/functions/muteFunctions');

exports.run = async (client, message, args) => {
  if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.channel.send(`${emojis.error} | ${message.author} Ops! Este comando é de uso exclusivo da staff!`)

  const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
  let reason = args.slice(1).join(" ") || "Não específicado.";
  if (!reason) reason = "Não específicado!"
  let areMuted = null
  if (!member) return message.channel.send(`${emojis.error} | ${message.author} Ops! Parece que o usuário não foi definido ou foi inserido de forma incorreta!\n${emojis.info} Tente: \`${process.env.PREFIX}mute (@membro/id) (motivo)\``)
  await member.roles.cache.map(r => { if (r.id == Client.roles.muteID) return areMuted = true })
  if (areMuted == true) return message.channel.send(`${emojis.error} | ${message.author} Ops! Parece que este membro já está mutado!`);
  if (message.member.roles.highest.position <= member.roles.highest.position) return message.channel.send(`${emojis.error} | ${message.author} Ops! Você não pode mutar alguém de cargo igual ou superior ao seu!`)


  const embed = new MessageEmbed().setDescription(`${emojis.mute} MUTE! ${emojis.mute}
Membro: ${member.user.tag} \`[${member.user.id}]\`
Staff: ${message.author} \`[${message.author.tag}]\`
Motivo: \`${reason}\``)
    .setThumbnail(member.user.displayAvatarURL({ size: 2048, dynamic: true }))

  let role = await message.guild.roles.cache.get(Client.roles.muteID)

  if (!role) {
    role = await createMuteRole(message)
  }

  try {
    await member.roles.add(Client.roles.muteID, { reason: reason })
    message.channel.send(message.author, embed)
    message.guild.channels.cache.get(Client.logs.mutes).send(embed)
    await updateChannelsPermissions(message.channel)
  } catch (err) {
    console.log(err)
    message.channel.send(`${emojis.error} | ${message.author} Ops! Ocorreu um erro na hora de mutar o usuário, verifique se o mesmo tem cargo maior que ou meu, ou se eu tenho permições para gerenciar cargos.`)
  }
}

exports.help = {
  name: "mute",
  aliases: ['mutar']
}