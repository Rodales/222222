const ms = require('ms');
const { MessageEmbed, MessageManager } = require('discord.js')

exports.run = async (client, message, args) => {
if (!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send(`${emojis.error} | ${message.author} Ops! Este comando é de uso exclusivo da staff!`)

  if (!['criar', 'create', 'finalizar', 'end', 'delete', 'deletar', 'reroll', 'resortear'].includes(args[0]))
    return message.channel.send(`${emojis.error} | Ops! ${message.author}, você deve utilizar o comando usando alguma das seguintes funções: \`create\`, \`reroll\`, \`end\` e \`delete\` `)

  if (['criar', 'create'].includes(args[0])) {
    return createGiveaway();
  } else if (['deletar', 'delete'].includes(args[0])) {
    return deleteGiveaway();
  } else if (['reroll', 'resortear'].includes(args[0])) {
    return rerollGiveaway();
  } else if (['end', 'finalizar'].includes(args[0])) {
    return finalizeGiveaway();
  }

  async function createGiveaway() {
    const prize = args.slice(3).join(' ');
    const winners = args[2]
    const timer = args[1]

    const error = `${emojis.error} | Ops! ${message.author}, você errou em alguma coisa na hora de criar o sorteio, tente seguir esta forma: \*\*!giveaway create 1h 1 Nitro Gaming\*\* \`!giveaway create (tempo) (ganhadores) (prêmio)\` `

    if (!prize) return message.channel.send(error)
    if (!winners) return message.channel.send(error)
    if (!timer) return message.channel.send(error)

    client.giveaway.start(message.channel, {
      time: ms(timer),
      winnerCount: parseInt(winners),
      prize: prize,
      messages: {
        giveaway: ':tada: Sorteio :tada:',
        giveawayEnded: ':tada: Sorteio Finalizado! :tada:',
        timeRemaining: 'Tempo restante: \`{duration}\`',
        inviteToParticipate: 'Reaja com 🎉 para participar.\nBoa Sorte!',
        winMessage: ':tada: Parabéns {winners}! Você(s) ganhou \`{prize}\`!\nGiveaway: {messageURL}',
        embedFooter: 'AceShop Sorteios',
        noWinner: `${emojis.error} | Giveaway cancelado!\n${emojis.info} Motivo: Falta de participantes elegíveis.`,
        hostedBy: 'Patrocinado por:',
        winners: 'Ganhador(es):',
        endedAt: 'Finalizado em',
        units: {
          seconds: "segundos",
          minutes: "minutos",
          hours: "horas",
          days: "dias",
          pluralS: false
        }
      }
    })
  }

  async function finalizeGiveaway() {
    const embed = new MessageEmbed()

    const id = args[1]

    if (!id)
      return message.channel.send(`${emojis.error} | Ops! ${message.author}, você deve inserir junto ao comando, o ID da mensagem do sorteio qual queres finalizar.`)

    client.giveaway.end(id).then(() => {
      message.channel.send(message.author, embed.setDescription(`${emojis.ok} | Pronto! Giveaway finalizado com sucesso.`).setColor('GREEN'))
    }).catch((err) => {
      message.channel.send(message.author, embed.setDescription(`${emojis.error} | Ops! Giveaway com ID \`${id}\` não foi encontrado!`).setColor('RED'))
    })
  }

  async function deleteGiveaway() {
    const embed = new MessageEmbed()

    const id = args[1]

    if (!id)
      return message.channel.send(`${emojis.error} | Ops! ${message.author}, você deve inserir junto ao comando, o ID da mensagem do sorteio qual queres deletar.`)

    client.giveaway.delete(id).then(() => {
      message.channel.send(message.author, embed.setDescription(`${emojis.ok} | Pronto! Giveaway deletado com sucesso.`).setColor('GREEN'))
    }).catch((err) => {
      message.channel.send(message.author, embed.setDescription(`${emojis.error} | Ops! Giveaway com ID \`${id}\` não foi encontrado!`).setColor('RED'))
    })
  }

  async function rerollGiveaway() {
    const embed = new MessageEmbed()

    const id = args[1]

    if (!id)
      return message.channel.send(`${emojis.error} | Ops! ${message.author}, você deve inserir junto ao comando, o ID da mensagem do sorteio qual queres dar reroll.`)

    client.giveaway.reroll(id, {
      messages: {
        congrat: `:tada: Novo(s) Ganhador(es): {winners}! Parabéns, você(s) ganhou \`{prize}\`!\nGiveaway: {messageURL}`,
        error: `${emojis.error} | Participantes insuficientes para um reroll, novo(s) ganhador(es) não puderam ser escolhidos.`
      }
    }).then(() => {
      message.channel.send(message.author, embed.setDescription(`${emojis.ok} | Sucesso! Reroll feito com sucesso.`).setColor('GREEN'))
    }).catch((err) => {
      message.channel.send(message.author, embed.setDescription(`${emojis.error} | Ops! Giveaway com ID \`${id}\` não foi encontrado!`).setColor('RED'))
    })
  }
}

exports.help = {
  name: "giveaway",
  aliases: ['sorteio', 'sortear', 'giveaways']
}
