const { MessageEmbed } = require("discord.js");
const MongoDB = require('../utils/mongoose/models/pagamentos');
const moment = require('moment');
moment.locale('pt-br')
exports.run = async (client, message, args) => {
  if (!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send(`${emojis.error} | ${message.author} Ops! Este comando é de uso exclusivo da staff!`)

  const filter = (user) => { return user.author.id === message.author.id }

  message.channel.send(`${emojis.load} | ${message.author} Qual o user que fez esta compra? (ID ou Menção)`).then(async msg => {
    msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async resp1 => {
      msg.channel.send(`${emojis.load} | ${message.author} Qual a conta?`).then(async msg2 => {
        msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async resp2 => {
          msg.channel.send(`${emojis.load} | ${message.author} Mande o comprovante da compra? (Link do imgur)`).then(async msg3 => {
            msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async resp3 => {
              msg.channel.send(`${emojis.load} | ${message.author} Diga os detalhes da conta...`).then(async msg4 => {
                msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async resp4 => {
                  msg.channel.send(`${emojis.load} | ${message.author} Verificando por contas com o mesmo email...`).then(async verifyMSG => {

                    const member = resp1.first().mentions.members.first() || message.guild.members.cache.get(resp1.first().content) || "Não Encontrado!"

                    const acc = {
                      member: member.id,
                      memberData: `[${member.user.tag} - ${member.user.id}]`,
                      staff: message.author.id,
                      staffData: `[${message.author.tag} - ${message.author.id}]`,
                      date: moment().format('LL [ás] LTS'),
                      account: resp2.first().content,
                      img: resp3.first().content,
                      details: resp4.first().content,
                    }

                    const embed = new MessageEmbed()
                      .setDescription(`
Conta: \`${acc.account}\`
Membro: <@!${acc.member}> \`${acc.memberData}\`
Staff: <@!${acc.staff}> \`${acc.staffData}\`
Data: \`${acc.date}\`
Detalhes: \`${acc.details}\`
Comprovante:
`).setImage(acc.img).setColor('GREEN')

                    const msg5 = await verifyMSG.edit(`${emojis.load} | ${message.author}, Tem certeza que deseja salvar este comprovante?`, embed)
                    const filterS = (reaction, user) => { return reaction.emoji.id === emojis.id.ok && user.id === message.author.id }
                    const filterN = (reaction, user) => { return reaction.emoji.id === emojis.id.error && user.id === message.author.id }

                    await msg5.react(emojis.id.ok);
                    await msg5.react(emojis.id.error);
                    const collect1S = await msg5.createReactionCollector(filterS, { time: 120000 })
                    const collect1N = await msg5.createReactionCollector(filterN, { time: 120000 })

                    collect1S.on('collect', async c => {
                      collect1S.stop()
                      collect1N.stop()
                      const newPag = await new MongoDB(acc)
                      await newPag.save()
                      try {
                        member.send(embed)
                      } catch (err) {
                        message.channel.send(`${emojis.info} | Hey ${message.author}, o comprovante não foi enviado ao user porque a DM dele está bloqueada.`)
                      }
                      message.guild.members.cache.get(acc.member).roles.add('846473375667847198')
                      message.guild.channels.cache.get('854782556272328724').send(embed)
                      return msg5.edit(`${emojis.ok} | Pagamento salvo.`)
                    })

                    collect1N.on('collect', c => {
                      collect1S.stop()
                      collect1N.stop()
                      return msg5.edit(`${emojis.error} | Pagamento cancelado.`)
                    })
                  })
                }).catch(err => {
                  console.log(err)
                  return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder o(s) id do(s) comprovante(s) de pagamento!`)
                })
              })
            }).catch(err => {
              console.log(err)
              return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder os detalhes do pagamento!`)
            })
          })
        }).catch(err => {
          console.log(err)
          return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder email da conta!`)
        })
      })
    }).catch(err => {
      console.log(err)
      return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder qual o id do membro!`)
    })
  })
}

exports.help = {
  name: "addpag",
  aliases: ['addpagamento']
}