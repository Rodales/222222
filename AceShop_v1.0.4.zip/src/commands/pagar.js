const { MessageEmbed } = require('discord.js');

exports.run = async (client, message, args) => {

  if (["854921392498671657", "854911602451939358"].includes(message.channel.parentID)) {
    return onIndexChannel();
  } else {
    return onRandomChannel();
  }

  async function onRandomChannel() {
    const embed = new MessageEmbed()
      .setDescription(`${emojis.info} | Nós temos as seguintes formas de pagamentos:\n\n${emojis.mp} - MercadoPago\n${emojis.picpay} - PicPay\n${emojis.pix} - Pix`)


    return message.channel.send(`${emojis.ok} | ${message.author}`, embed)
  }

  async function onIndexChannel() {

    const filter = (user) => { return user.author === message.author };

    const embed = new MessageEmbed().setDescription(`${emojis.ok} | ${message.author} Qual o valor do pagamento? (Apenas números inteiros, sem pontos ou virgulas)`)
    message.channel.send(message.author, embed).then(async msg => {
      msg.channel.awaitMessages(filter, { max: 1, timer: 600000, errors: ['time'] }).then(async resp => {
        const money = resp.first().content

        if (Number.isInteger(money)) return message.channel.send(`${emojis.error} | ${message.author}, você deve inserir apenas números inteiros!`)

        msg.edit(embed.setDescription(`${emojis.ok} | ${message.author} Qual o método de pagamento?\n\n${emojis.mp} - MercadoPago\n${emojis.picpay} - PicPay\n${emojis.pix} - Pix`))

        await msg.react(emojis.id.mp);
        await msg.react(emojis.id.picpay);
        await msg.react(emojis.id.pix);

        const filterMercadoPago = (reaction, user) => { return reaction.emoji.id === emojis.id.mp && user.id === message.author.id };
        const filterPicPay = (reaction, user) => { return reaction.emoji.id === emojis.id.picpay && user.id === message.author.id };
        const filterPix = (reaction, user) => { return reaction.emoji.id === emojis.id.pix && user.id === message.author.id };

        const MercadoPago = await msg.createReactionCollector(filterMercadoPago, { timeout: 300000 });
        const PicPay = await msg.createReactionCollector(filterPicPay, { timeout: 300000 });
        const Pix = await msg.createReactionCollector(filterPix, { timeout: 300000 });

        MercadoPago.on('collect', async () => {
          MercadoPago.stop();
          PicPay.stop();
          Pix.stop();

          msg.edit(embed.setDescription(`${emojis.ok} | ${message.author} Seu vendedor está criando o seu link de pagamento, aguarde!\n\n${emojis.money} a Pagar: \`R$ ${money}\`\n${emojis.mp} Método de pagamento: \`MercadoPago\``))
          msg.channel.send("<@&846466306521301034>")
        });

        PicPay.on('collect', async () => {
          MercadoPago.stop();
          PicPay.stop();
          Pix.stop();

          msg.edit(embed.setDescription(`${emojis.ok} | ${message.author} Agora é com você!\n\n${emojis.money} a Pagar: \`R$ ${money}\`\n${emojis.picpay} Método de pagamento: \`PicPay\`\n\n${emojis.info} Você pode pagar [clicando aqui](https://picpay.me/aceshop/${money}.0)`))
          msg.channel.send(`${emojis.info} Atenção! Após o pagamento é necessário que seja enviado o comprovante do mesmo!`)
        });

        Pix.on('collect', async () => {
          MercadoPago.stop();
          PicPay.stop();
          Pix.stop();

          msg.edit(embed.setDescription(`${emojis.ok} | ${message.author} Agora é com você!\n\n${emojis.money} a Pagar: \`R$ ${money}\`\n${emojis.pix} Método de pagamento: \`Pix\`\n\n${emojis.info} Você pode pagar escaneando o QR Code abaixo:`).setImage("https://i.imgur.com/w6pHybs.png"))
          msg.channel.send(`${emojis.info} Atenção! Após o pagamento é necessário que seja enviado o comprovante do mesmo!`)
        });
      }).catch(err => {
        return message.channel.send(`${emojis.error} | Ops ${message.author}, você demorou de mais para responder qual o valor do pagamento.`)
      })
    })
  }
}

exports.help = {
  name: "pagar",
  aliases: ['pay']
}