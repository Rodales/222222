const { MessageEmbed } = require("discord.js")

exports.run = async (client, message, args) => {
if (!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send(`${emojis.error} | ${message.author} Ops! Este comando é de uso exclusivo da staff!`)

  const embed = new MessageEmbed()
    .setColor('YELLOW')
    .setAuthor("Captcha AceShop", client.user.displayAvatarURL())
    .setDescription(`:flag_br: - \`Português\`\n> Olá seja bem vindo a central de atendimento da \_\_\*\*AceShop\*\*\_\_.\nReaja com:\n${emojis.money} - Ticket Compras\n${emojis.info} - Tickets Dúvidas\n\n:flag_us: - \`English\`\n> Hello, welcome to the call center of \_\_\*\*AceShop\*\*\_\_.\nReact with:\n${emojis.money} - Ticket Shop\n${emojis.info} - Tickets Questions`)

  const c = await message.channel.send(embed);
  c.react(emojis.id.money)
  c.react(emojis.id.info)
}

exports.help = {
  name: "vitu"
}
