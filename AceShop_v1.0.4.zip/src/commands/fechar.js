const fetchAll = require('discord-fetch-all');
const { MessageAttachment, MessageEmbed } = require('discord.js');
const config = require('../../baseConfigs.json')

exports.run = async (client, message, args) => {

  if (!message.member.hasPermission('ADMINISTRATOR')) return;

  let channel = message.channel

  if (!['854911602451939358', '854921392498671657'].includes(channel.parentID)) {
    return message.channel.send(`${emojis.error} | Hey ${message.author}, você consegue usar esse comando apenas em canais das categorias <#854911602451939358> e <#854921392498671657>!`)
  }

  await message.channel.send(message.author, client.embed
    .setTimestamp()
    .setColor('RED')
    .setFooter(`© 2021 | ${message.guild.name} - All rights reserved.`, message.guild.iconURL({ dynamic: true }))
    .setDescription(`${emojis.load} Tem certeza que deseja fechar este ticket?`)).then(async msg => {
      await msg.react(emojis.id.ok)

      const filter = (reaction, user) => { return reaction.emoji.id === emojis.id.ok && user.id == message.author.id }
      const collectR = await msg.createReactionCollector(filter, { time: 60000 * 60 })

      collectR.on('collect', async c => {
        message.channel.send(`${emojis.ok} ${message.author} OK! Deletando em 5 segundos...`)
        const messages = await fetchAll.messages(channel, {
          reverseArray: true,
          userOnly: false,
          botOnly: false,
          pinnedOnly: false
        })

        const logEmbed = new Array();
        logEmbed.push("AceShop")
        messages[0].embeds[0].fields.map(field => {
          logEmbed.push(field.name)
          logEmbed.push(field.value)
        })

        const buffer = Buffer.from(`${logEmbed.join('\n')}\n\n${messages.join('\n')}\n\nDeveloped by CTO of Brand Developers`)
        const attachment = new MessageAttachment(buffer, `logs-${channel.name}.log`)

        let user = client.users.cache.get(channel.topic)
        let link

        let embed = new MessageEmbed().setColor('RED').setTimestamp().setFooter(`© 2021 | ${message.guild.name} - All rights reserved.`, message.guild.iconURL({ dynamic: true }))

        switch (channel.parentID) {
          case "854911602451939358":
            const staffC = message.guild.channels.cache.get(config.logs.tickets)
            try {
              const msgUC = await user.send(`\*\*${user.tag}\*\* \`[${user.id}]\``, { embed, files: [attachment] })
              await msgUC.edit(embed.setAuthor('Shop/Compras', client.user.displayAvatarURL()).setDescription(`:flag_br: - \`Português\`\n> ${emojis.ok} Ticket finalizado e arquivado com sucesso!.\n\n\n:flag_us: - \`English\`\n> ${emojis.ok} Ticket successfully finalized and archived\n${emojis.info} Logs:  [Download](${msgUC.attachments.first().url})`))
            } catch (err) {
              console.log('USER DM Lock')
            }
            const msgSC = await staffC.send(`\*\*${user.tag}\*\* \`[${user.id}]\``, { embed, files: [attachment] })
            await msgSC.edit(embed.setAuthor('Shop/Compras', client.user.displayAvatarURL()).setDescription(`:flag_br: - \`Português\`\n> ${emojis.ok} Ticket finalizado e arquivado com sucesso!.\n\n\n:flag_us: - \`English\`\n> ${emojis.ok} Ticket successfully finalized and archived\n${emojis.info} Logs:  [Download](${msgSC.attachments.first().url})`))
            break;
          case "854921392498671657":
            const staffS = message.guild.channels.cache.get(config.logs.tickets)
            try {
              const msgUS = await user.send(`\*\*${user.tag}\*\* \`[${user.id}]\``, { embed, files: [attachment] })
              await msgUS.edit(embed.setAuthor('Questions/Dúvidas', client.user.displayAvatarURL()).setDescription(`:flag_br: - \`Português\`\n> ${emojis.ok} Ticket finalizado e arquivado com sucesso!.\n\n\n:flag_us: - \`English\`\n> ${emojis.ok} Ticket successfully finalized and archived\n${emojis.info} Logs:  [Download](${msgUS.attachments.first().url})`))
            } catch (err) {
              console.log('USER DM Lock')
            }
            const msgSS = await staffS.send(`\*\*${user.tag}\*\* \`[${user.id}]\``, { embed, files: [attachment] })
            await msgSS.edit(embed.setAuthor('Questions/Dúvidas', client.user.displayAvatarURL()).setDescription(`:flag_br: - \`Português\`\n> ${emojis.ok} Ticket finalizado e arquivado com sucesso!.\n\n\n:flag_us: - \`English\`\n> ${emojis.ok} Ticket successfully finalized and archived\n${emojis.info} Logs:  [Download](${msgSS.attachments.first().url})`))
            break;
        }
        channel.delete({ timeout: 5000 })
      })
    })
}

exports.help = {
  name: "close",
  aliases: ['fechar']
}