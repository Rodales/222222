const { MessageEmbed } = require('discord.js');
const MongoDB = require('../utils/mongoose/models/pagamentos');

exports.run = async (client, message, args) => {

  if (!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send(`${emojis.error} | ${message.author} Ops! Este comando é de uso exclusivo da staff!`)

  if (!args[0]) {
    return noSearch();
  } else {
    return search();
  }

  async function search() {
    const acc = await MongoDB.findOne({ account: args[0] })

    if (!acc) return message.channel.send(`${emojis.error} | ${message.author} Hey, a conta \`${args[0]}\` \_\_\*\*NÃO\*\*\_\_ existe!`)

    const embed = new MessageEmbed()
      .setColor('0000FF')
      .setFooter(message.author.tag, message.author.displayAvatarURL({ dynamic: true }))
      .setAuthor(message.guild.name, message.guild.iconURL({ dynamic: true }))

    const img = acc.img[0]

    embed.setDescription(`
Conta: \`${acc.account}\`
Membro: <@!${acc.member}> \`${acc.memberData}\`
Staff: <@!${acc.staff}> \`${acc.staffData}\`
Data: \`${acc.date}\`
Detalhes: \`${acc.details}\`
Comprovante:
`).setImage(img)

    message.channel.send(embed)
  }

  async function noSearch() {

    let accounts

    try {
      accounts = await MongoDB.find();

      const pages = Math.floor(accounts.length / 10);
      let page = 1

      const embed = new MessageEmbed()
        .setFooter(`Página ${page} de ${pages}`)
        .setDescription(`${emojis.accounts} Pagamentos ${emojis.accounts}

  `)

      message.channel.send(`${emojis.load} | Carregando...`).then(async msg => {
        baseAccounts()

        if (pages === 0) {
          return baseAccounts()
        } else {

          await msg.react('⏮')
          await msg.react('⏭')

          const nextFilter = (reaction, user) => { return reaction.emoji.name === "⏭" && user.id === message.author.id };
          const prevFilter = (reaction, user) => { return reaction.emoji.name === "⏮" && user.id === message.author.id };

          const nextCollector = await msg.createReactionCollector(nextFilter, { time: 300000 });
          const prevCollector = await msg.createReactionCollector(prevFilter, { time: 300000 })

          nextCollector.on('collect', async () => { getAccounts("next") })
          prevCollector.on('collect', async () => { getAccounts("prev") })

          async function getAccounts(type) {
            switch (type) {
              case "next": {
                if (Number(page + 1) > pages) {
                  page = 1
                  return baseAccounts()
                } else {
                  page = page + 1
                };

                const start = Number(page - 1 + "0")
                const end = Number(page - 1 + "9")
                const acc = new Array
                for (let i = start; i <= end; i++) {
                  if (accounts[i]) {
                    acc.push(`Conta \`${accounts[i].account}\``)
                  } else {
                    acc.push('')
                  }
                }
                acc.push('')
                msg.edit(`${emojis.info} | ${message.author} Hey, caso você queira ver um pagamento específico, você deve utilizar este comando, inserindo a conta do pagamento que desejas ver as informações!`, embed.setFooter(`Página ${page} de ${pages}`).setDescription(`${emojis.accounts} Pagamentos ${emojis.accounts}\n${acc.join("\n")}`))
              }
              case "prev": {
                if (Number(page - 1) > pages) {
                  page = 1
                  return baseAccounts()
                } else {
                  page = page - 1
                };

                const start = Number(page - 1 + "0")
                const end = Number(page - 1 + "9")
                const acc = new Array
                for (let i = start; i <= end; i++) {
                  if (accounts[i]) {
                    acc.push(`Conta \`${accounts[i].account}\``)
                  } else {
                    acc.push('')
                  }
                }
                acc.push('')
                msg.edit(`${emojis.info} | ${message.author} Hey, caso você queira ver um pagamento específico, você deve utilizar este comando, inserindo a conta do pagamento que desejas ver as informações!`, embed.setFooter(`Página ${page} de ${pages}`).setDescription(`${emojis.accounts} Pagamentos ${emojis.accounts}\n${acc.join("\n")}`))
              }
            }
          }
        }

        async function baseAccounts() {
          const acc = new Array
          for (let i = 0; i <= 9; i++) {
            if (accounts[i]) {
              acc.push(`Conta \`${accounts[i].account}\``)
            } else {
              acc.push('')
            }
          }
          acc.push('')
          msg.edit(`${emojis.info} | ${message.author} Hey, caso você queira ver um pagamento específico, você deve utilizar este comando, inserindo a conta do pagamento que desejas ver as informações!`, embed.setFooter(`Página ${page} de ${pages}`).setDescription(`${emojis.accounts} Pagamentos ${emojis.accounts}\n${acc.join("\n")}`))
        }
      })
    } catch (err) {
      console.log(err)
      message.channel.send(`${emojis.error} | Ops! ${message.author}, parece que não há contas registradas ou ocorreu um erro.`)
    }
  }
}

exports.help = {
  name: "verpagamentos",
  aliases: ['viewpag']
}
