const { MessageEmbed } = require("discord.js");
const MongoDB = require('../utils/mongoose/models/accounts');

exports.run = async (client, message, args) => {
  if (!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send(`${emojis.error} | ${message.author} Ops! Este comando é de uso exclusivo da staff!`)

  const filter = (user) => { return user.author.id === message.author.id }

  message.channel.send(`${emojis.load} | ${message.author} Qual o email da conta?`).then(async msg => {
    msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async resp1 => {
      msg.channel.send(`${emojis.load} | ${message.author} Qual a senha da conta?`).then(async msg2 => {
        msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async resp2 => {
          msg.channel.send(`${emojis.load} | ${message.author} Qual imgur da conta?`).then(async msg3 => {
            msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async resp3 => {
              msg.channel.send(`${emojis.load} | ${message.author} Diga os detalhes da conta...`).then(async msg4 => {
                msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(async resp4 => {
                  msg.channel.send(`${emojis.load} | ${message.author} Verificando por contas com o mesmo email...`).then(async verifyMSG => {

                    let isAnnounced = null
                    let hasSB = null
                    let dateSB
                    const filterS = (reaction, user) => { return reaction.emoji.id === emojis.id.ok && user.id === message.author.id }
                    const filterN = (reaction, user) => { return reaction.emoji.id === emojis.id.error && user.id === message.author.id }

                    msg.channel.send(`${emojis.load} | ${message.author} Esta conta já foi anúnciada?`).then(async msg5 => {
                      await msg5.react(emojis.id.ok);
                      await msg5.react(emojis.id.error);
                      const collect1S = await msg5.createReactionCollector(filterS, { time: 120000 })
                      const collect1N = await msg5.createReactionCollector(filterN, { time: 120000 })

                      collect1S.on('collect', c => {
                        collect1S.stop()
                        collect1N.stop()
                        isAnnounced = true
                        return SB()
                      })

                      collect1N.on('collect', c => {
                        collect1S.stop()
                        collect1N.stop()
                        isAnnounced = false
                        return SB()
                      })

                      async function SB() {
                        msg.channel.send(`${emojis.load} | ${message.author} Esta conta possuí SB?`).then(async msg6 => {
                          await msg6.react(emojis.id.ok);
                          await msg6.react(emojis.id.error);
                          const collect2S = await msg6.createReactionCollector(filterS, { time: 120000 })
                          const collect2N = await msg6.createReactionCollector(filterN, { time: 120000 })

                          collect2S.on('collect', c => {
                            collect2S.stop()
                            collect2N.stop()
                            hasSB = emojis.ok
                            return hasSBTrue()
                          })

                          collect2N.on('collect', c => {
                            collect2S.stop()
                            collect2N.stop()
                            hasSB = emojis.error
                            return blizzard()
                          })
                          async function blizzard() {
                            msg.channel.send(`${emojis.load} | ${message.author} Esta conta possuí Blizzard?`).then(async msg7 => {

                              await msg7.react(emojis.id.ok);
                              await msg7.react(emojis.id.error);
                              const collect3S = await msg7.createReactionCollector(filterS, { time: 120000 })
                              const collect3N = await msg7.createReactionCollector(filterN, { time: 120000 })

                              collect3S.on('collect', c => {
                                collect3S.stop()
                                collect3N.stop()
                                return getBlizzardInfo()
                              })

                              collect3N.on('collect', c => {
                                collect3S.stop()
                                collect3N.stop()
                                const data = {
                                  email: resp1.first().content,
                                  password: resp2.first().content,
                                  imgur: resp3.first().content,
                                  details: resp4.first().content,
                                  isAnnounced: isAnnounced,
                                  banned: hasSB,
                                  banDate: dateSB,
                                  blizzard: emojis.error
                                }
                                return saveData(data)
                              })

                              async function saveData(data) {
                                const account = await new MongoDB(data)
                                await account.save()
                                const embed = new MessageEmbed()
                                  .addField(`Email:`, `\`\`\`\n${data.email}\n\`\`\``, true)
                                  .addField(`Password:`, `\`\`\`\n${data.password}\n\`\`\``, true)
                                  .addField(`Imgur:`, `\`\`\`\n${data.imgur}\n\`\`\``, true)
                                  .addField(`Detalhes:`, `\`\`\`\n${data.details}\n\`\`\``)
                                msg.channel.send(`${emojis.ok} | ${message.author} Pronto, conta registrada com sucesso!`)
                              }

                              async function getBlizzardInfo() {
                                msg.channel.send(`${emojis.load} | ${message.author} Qual o email Blizzard?`).then(async msg8 => {
                                  msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(blizzardEmail => {
                                    msg.channel.send(`${emojis.load} | ${message.author} Qual a senha Blizzard?`).then(async msg9 => {
                                      msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(blizzardPassword => {
                                        const data = {
                                          email: resp1.first().content,
                                          password: resp2.first().content,
                                          imgur: resp3.first().content,
                                          details: resp4.first().content,
                                          isAnnounced: isAnnounced,
                                          banned: hasSB,
                                          banDate: dateSB,
                                          blizzard: emojis.error,
                                          blizzardEmail: blizzardEmail.first().content,
                                          blizzardPass: blizzardPassword.first().content
                                        }
                                        return saveData(data)
                                      }).catch(err => {
                                        console.log(err)
                                        return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder a senha Blizzard!`)
                                      })
                                    }).catch(err => {
                                      return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder o email Blizzard!`)
                                    })
                                  })
                                })
                              }
                            })
                          }
                          async function hasSBTrue() {
                            msg.channel.send(`${emojis.load} | ${message.author} Qual a data do SB?`).then(async sbMSG => {
                              msg.channel.awaitMessages(filter, { max: 1, time: 120000, errors: ['timer'] }).then(sbDate => {
                                dateSB = sbDate.first().content
                                return blizzard()
                              }).catch(err => {
                                return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder a data do SB!`)
                              })
                            })
                          }
                        })
                      }
                    })
                  })
                }).catch(err => {
                  return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder o id do canal para enviar a embed!`)
                })
              })
            }).catch(err => {
              return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder a imagem da embed!`)
            })
          })
        }).catch(err => {
          return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder a mensagem da embed!`)
        })
      })
    }).catch(err => {
      return message.channel.send(`${emojis.error} | ${message.author} Ops! Você demorou muito para responder qual o título da embed!`)
    })
  })
}

exports.help = {
  name: "addcod",
  aliases: ['addconta']
}