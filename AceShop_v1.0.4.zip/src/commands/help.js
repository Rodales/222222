const { MessageEmbed } = require("discord.js")

exports.run = async (client, message, args) => {

  const embed = new MessageEmbed()
    .setColor('YELLOW')
    .setAuthor("Help AceShop", client.user.displayAvatarURL())
    .setDescription(`${emojis.info} Comandos Membro's
\`!help\` - Comando de help com todos os comandos.
\`!pagar\` - Exibe as formas de pagamento, ou abre uma função para pagar.
`)

  const embedStaff = new MessageEmbed()
    .setColor('GREEN')
    .setAuthor("Help AceShop", client.user.displayAvatarURL())
    .setFooter(message.author.tag, message.author.displayAvatarURL({ dynamic: true }))
    .setDescription(`${emojis.info} Comandos Staff's
\`!addCOD\` - Adicionar uma conta de COD ao banco de dados.
\`!addPAG\` - Adicionar um pagamento (com comprovante).
\`!ban\` - Banir algum membro por id ou menção.
\`!fechar\` - Fechar um tícket (só funciona em tickets).
\`!giveaway\` - Criar, finalizar, rerolls e deletar um sorteio.
\`!help\` - Comando de help com todos os comandos.
\`!mute\` - Muta algum usuário por menção ou ID.
\`!pagar\` - Exibe as formas de pagamento, ou abre uma função para pagar.
\`!say\` - Envia uma mensagem/embed.
\`!unmute\` - Desmuta um usuário já mutado.
\`!viewCOD\` - Vizualiza todas as contas adicionadas na database, coloque o email de uma específica para ver mais detalhes.
\`!viewPAG\` - Vizualiza todos os pagamentos adicionados a database, coloque um pagamento em específico para ver mais detalhes.
`)

  if (!message.member.hasPermission('ADMINISTRATOR')) {
    return message.channel.send(`${emojis.ok} | ${message.author}`, embed)
  } else {
    return message.channel.send(`${emojis.ok} | ${message.author}`, embedStaff)
  }
}

exports.help = {
  name: "help",
  aliases: ['ajuda']
}