const pagamento = require('../utils/mongoose/models/accounts')

exports.run = async (client, message, args) => {
  if (!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send(`${emojis.error} | ${message.author} Ops! Este comando é de uso exclusivo da staff!`)

  if (!args[0])
    return message.channel.send(`${emojis.info} | Ops! ${message.author}, VOcê deve inserir junto ao comando, qual conta desejas remover do sistema!`)

  const pag = await pagamento.findOneAndDelete({ email: args[0] })

  return message.channel.send(`${emojis.ok} | Pronto! Conta deletada com sucesso!`)
}
exports.help = {
  name: "remcod",
  aliases: ["removerconta", "remconta"]
}