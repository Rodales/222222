const { MessageEmbed } = require("discord.js");
const Client = require('../../baseConfigs.json');

exports.run = async (client, message, args) => {
  if (!message.member.hasPermission('BAN_MEMBERS')) return message.channel.send(`${emojis.error} | ${message.author} Ops! Este comando é de uso exclusivo da staff!`)

  const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
  const reason = args.slice(1).join(" ");
  if (!member) return message.channel.send(`${emojis.error} | ${message.author} Ops! Parece que o usuário não foi definido ou foi inserido de forma incorreta!\n${emojis.info} Tente: \`${process.env.PREFIX}ban (@membro/id) (motivo)\``)

  if (message.member.roles.highest.position <= member.roles.highest.position) return message.channel.send(`${emojis.error} | ${message.author} Ops! Você não pode banir alguém de cargo igual ou superior ao seu!`)

  const embed = new MessageEmbed().setDescription(`${emojis.info} BAN! ${emojis.info}
Membro: ${member.user.tag} \`[${member.user.id}]\`
Staff: ${message.author} \`[${message.author.tag}]\`
Motivo: \`${reason}\``)
    .setThumbnail(member.user.displayAvatarURL({ size: 2048, dynamic: true }))

  try {
    await member.ban({ reason: reason })
    message.channel.send(message.author, embed)
    message.guild.channels.cache.get(Client.logs.ban).send(embed)
  } catch (err) {
    message.channel.send(`${emojis.error} | ${message.author} Ops! Ocorreu um erro na hora de banir o usuário, verifique se o mesmo tem cargo maior que ou meu, ou se eu tenho permições para banir membros.`)
  }
}

exports.help = {
  name: "ban",
  aliases: ['banir']
}
